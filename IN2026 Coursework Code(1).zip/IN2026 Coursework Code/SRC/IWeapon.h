#ifndef __IWEAPON_H__
#define __IWEAPON_H__

class IWeapon
{
public:
	virtual void Shoot(void) = 0;
};

#endif